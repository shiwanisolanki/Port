import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <header className="header-section">
      <div className="container pt-3">
        <nav className="navbar navbar-expand-lg shadow rounded">
          <a className="navbar-brand text-white fs-5" href="#">
            Shivani
          </a>

          <button
            className="navbar-toggler bg-light"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="navbarNav">
            <div className="d-flex flex-grow-1 justify-content-between align-items-center w-100">
            
              <ul className="navbar-nav mx-auto text-center d-flex gap-4">
                <li className="nav-item">
                  <Link className="nav-link text-white" to="/">Home</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link text-white" to={"/About"}>About</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link text-white" to={"/Projects"}>Project</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link text-white" to={"/contact"}>Contact Us</Link>
                </li>
              </ul>

              {/* Social Icons - Right */}
              <div className="d-flex gap-3 social-link">
                <a href="https://www.facebook.com/shiwani.solanki4" target="_blank" rel="noopener noreferrer" className="text-white fs-6">
                  <i className="fab fa-facebook-f"></i>
                </a>
                <a href="https://www.instagram.com/shiwanidjrana" target="_blank" rel="noopener noreferrer" className="text-white fs-6">
                  <i className="fab fa-instagram"></i>
                </a>
                <a href="https://linkedin.com/in/shiwani-solanki" target="_blank" rel="noopener noreferrer" className="text-white fs-6">
                  <i className="fab fa-linkedin-in"></i>
                </a>
              </div>

            </div>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;
