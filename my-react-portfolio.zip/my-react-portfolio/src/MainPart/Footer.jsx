import React from 'react';
import { Link } from 'react-router-dom';

function Footer() {
  return (
    <footer className="text-light pb-3">
      <div className="container">
        <div className="row gy-4">

          {/* About */}
          <div className="col-md-4">
            <h5>About Me</h5>
            <p>
              I am a passionate web developer with expertise in creating responsive and user-friendly websites.
              Let's work together to bring your ideas to life!
            </p>
          </div>

          {/* Quick Links */}
          <div className="col-md-4">
            <h5>Quick Links</h5>
            <ul className="list-unstyled d-flex flex-column gap-2">
              <Link to="/" className="text-light text-decoration-none">Home</Link>
               <Link className="text-light text-decoration-none" to={"/About"}>About</Link>
                             <Link className="text-light text-decoration-none" to={"/About"}>Portfolio</Link>
               <Link className="text-light text-decoration-none" to={"/About"}>Contact</Link>

            </ul>
          </div>

          {/* Contact */}
          <div className="col-md-4">
            <h5>Contact</h5>
            <ul className="list-unstyled">
              <li>Email: <a href="mailto:shiwanisolanki.13@gmail.com" className="text-light">shiwanisolanki.13@gmail.com</a></li>
              <li>Phone: <a href="tel:+917016920443" className="text-light">7016920443</a></li>
              <li>Location: Gandhinagar, Gujarat</li>
            </ul>
              <div class="d-flex gap-3 social-link justify-content-center">
                <a href="https://facebook.com/shiwani.solanki4" target="_blank" rel="noopener noreferrer" class="text-white fs-6"><i class="fab fa-facebook-f"></i></a>
                <a href="https://instagram.com/shiwanidjrana" target="_blank" rel="noopener noreferrer" class="text-white fs-6"><i class="fab fa-instagram"></i></a>
                <a href="https://linkedin.com/in/shiwani-solanki" target="_blank" rel="noopener noreferrer" class="text-white fs-6"><i class="fab fa-linkedin-in"></i></a></div>
          </div>


        </div>

        
      </div>
      <hr className="border-light mt-4" />
        <p className="text-center m-0">© 2025 Shivani. All Rights Reserved.</p>
    </footer>
  );
}

export default Footer;
