import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import "bootstrap/dist/css/bootstrap.css";
import "bootstrap/dist/js/bootstrap.bundle";
import { createBrowserRouter, RouterProvider} from "react-router-dom";
import Home from "./Components/Home";
import About from './Components/About';
import Projects from './Components/Projects';
import NotFound from './Components/NotFound';
import Projectdetails from './Components/Projectdetails';
import Contact from './Components/contact';

//  Define routes
const router = createBrowserRouter([
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "About",
    element: <About />,
  },
   {
    path: "Projects",
    element: <Projects />,
  },
  {
    path: "Contact",
    element: <Contact />,
  },
  {
    path: "*",
    element: <NotFound />
  },
  { path: '/project/:id', 
    element: <Projectdetails /> }
]);

//  Render the app with RouterProvider
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>
);

