// src/data/educationData.js
const educationData = {
  education: [
    {
      title: "IT Engineering",
      date: "2013-2017",
      desc: "Portfolio showing skills, experience, and creativity."
    },
    {
      title: "React Internship",
      date: "2025 in ExcelPTP",
      desc: "Projects showing adaptability and unique client needs."
    }
  ],
  experience: [
    {
      company: "Queryfinders Solution",
      duration: "2.5 Years",
      role: "Web Designer",
      desc: "Reprehenderit in voluptate velit esse cillum dolore."
    },
    {
      company: "ExcelPTP",
      duration: "6 month",
      role: "Frontend Developer",
      desc: "Responsive web design projects highlighted here."
    }
  ]
};

export default educationData;
