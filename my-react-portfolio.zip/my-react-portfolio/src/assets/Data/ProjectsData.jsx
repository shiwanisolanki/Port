export let ProjectImages = [
  {
    id: 1,
    image: "/assets/images/Queryfinders.webp",
    title: "Queryfinders Solution",
    description: "A modern IT services company website with responsive design."
  },
  {
    id: 2,
    image: "/assets/images/aashirwad.webp",
    title: "Aashirwad Seva Sankul Trust",
  description: "A thoughtfully designed website showcasing cultural, religious, and social event services with photo galleries and contact information."
  },
  {
    id: 3,
    image: "/assets/images/agrinne.webp",
    title: "Agrinne Naturals",
    description: "An organic product ecommerce site."
  },
  {
    id: 4,
    image: "/assets/images/sagarmachinery.webp",
    title: "Sagar Machinery",
    description: "Industrial machinery manufacturer site."
  },
  {
    id: 5,
    image: "/assets/images/sharpmindquest.webp",
    title: "SharpMind Quest",
    description: "Educational consultancy landing page."
  },
  {
    id: 6,
    image: "/assets/images/vellyprofessionals.webp",
    title: "Velly Professionals",
    description: "Salon and beauty service portfolio."
  },
  {
    id: 7,
    image: "/assets/images/portfolio.png",
    title: "My Portfolio",
    description: "here is my personal portfolio."
  }
];
