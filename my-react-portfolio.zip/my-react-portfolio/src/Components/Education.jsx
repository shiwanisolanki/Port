import React from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css';
import { useEffect } from 'react';
import customline from "../assets/custom-line.webp"
import educationData from '../assets/Data/EducationData';
import expertimg from "../assets/expert-img.webp"

function Education() {
    useEffect(() => {
        AOS.init({ duration: 1000, once: true });
    }, []);
    return (
        <section className="education-section" id="resume">
            <div className="container">

                {/* Section Title */}
                <div className="text-center mb-5">
                    <h2 className="section-title">Education & Experience</h2>
                    <p className="section-subtitle">Empowering Creativity <br />through</p>
                </div>

                {/* Education Section */}
                <h3 className="subheading mb-5 text-white" data-aos="fade-up">
                    Education
                    <span className='ms-4'>
                        <img alt="custom-line" width="81" height="6" style={{ color: 'transparent' }} src={customline} />
                    </span>
                </h3>

                <div className="row g-5">
                    {educationData.education.map((edu, i) => (

                        <div className="col-md-6 mb-4" key={i}>
                            <div className="card p-3 shadow-sm bg-gray shadow rounded-3 card-hover-3d" data-aos="fade-up" data-aos-delay={i * 100}>
                                <h5 className="edu-role text-white">{edu.title}</h5>
                                <h6 className="edu-date text-white">{edu.date}</h6>
                                <p className="edu-desc text-gray mt-3">{edu.desc}</p>
                            </div>

                        </div>
                    ))}

                </div>

                {/* Experience */}
           
                <div className="row mt-5">
                    <div className="col-md-6">
     <h3 className="subheading mb-5 text-white" data-aos="fade-up">Experiences
                    <span className='ms-4'>
                        <img alt="custom-line" width="81" height="6" style={{ color: 'transparent' }} src={customline} />
                    </span>
                </h3>
                        {educationData.experience.map((exp, i) => (
                            <div className="col mb-4" key={i}>
                                <div className=" p-3 shadow-sm" data-aos="fade-up" data-aos-delay={i * 100}>
                                    <h5 className="exp-company text-pink" >{exp.company} <small>({exp.duration})</small></h5>
                                    <h6 className="exp-role text-white">{exp.role}</h6>
                                    <p className="exp-desc text-gray mt-3">{exp.desc}</p>
                                </div>
                            </div>

                        ))}
                    </div>
                    <div className="col-md-6 right-img">
                        <img src={expertimg} alt="" className='img-fluid rounded-3'/>
                    </div>
                </div>


            </div>
        </section>
    );
}

export default Education;
