import React from 'react'
import Header from '../MainPart/Header'
import SubBanner from './SubBanner'
import Footer from '../MainPart/Footer'
import Education from './Education'
import aboutBanner from '../assets/banner-background-one.jpg';


function About() {
  return (
    
    <>
    <Header/>
    <SubBanner 
        title="About Me" 
        bannerImage={aboutBanner} 
        currentPage="About" 
      />
    <Education/>
    <Footer/>
    </>
  )
}

export default About