import React from 'react'
import Header from '../MainPart/Header'
import SubBanner from './SubBanner'
import Footer from '../MainPart/Footer'
import aboutBanner from '../assets/banner-background-one.jpg';
import { ProjectImages } from '../assets/Data/ProjectsData';
import { useParams } from 'react-router-dom';
import { Link } from 'react-router-dom';




function Projectdetails() {
  const { id } = useParams();
  const project = ProjectImages.find((p) => p.id === parseInt(id));
if (!project) {
    return (
      <div className="container py-5 text-center">
        <h2 className="text-danger">Project Not Found</h2>
      </div>
    );
  }
  return (
<>
<Header/>
<SubBanner title="Project Details" 
        bannerImage={aboutBanner} 
        currentPage="About" />
 <section className="container py-5 ProjectDetails">
   {/* Section Title */}
                <div className="text-center mb-5">
<h2 className="section-title">Project Showcase</h2>
<p className="section-subtitle">What, why,  <br /> and how</p>
                </div>
      <div className="row">
        <div className="col-md-6">
          <img
            src={project.image}
            alt={project.title}
            className="img-fluid rounded shadow"
            style={{ objectFit: 'cover', height: '400px' }}
          />
        </div>
        <div className="col-md-6">
          <h2 className="mb-3">{project.title}</h2>
         <p className="lead">{project.description}</p>


          {/* Optional: Add a back button */}
<Link to={"/Projects"} className="btn btn-danger mt-3">
            ← Back to Portfolio
          </Link>
        </div>
      </div>
    </section>

<Footer/>
</>
)
}

export default Projectdetails