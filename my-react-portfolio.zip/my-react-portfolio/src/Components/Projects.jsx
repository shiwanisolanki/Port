import React from 'react'
import Header from '../MainPart/Header'
import SubBanner from './SubBanner'
import Footer from '../MainPart/Footer'
import portfolioBanner from '../assets/banner-background-one.jpg';
import Portfolio from './Portfolio';


function Projects() {
  return (
     <>
    <Header/>
    <SubBanner 
        title="My Projects" 
        bannerImage={portfolioBanner} 
        currentPage="Projects" 
      />
      <Portfolio/>
    <Footer/>
    </>
  )
}

export default Projects