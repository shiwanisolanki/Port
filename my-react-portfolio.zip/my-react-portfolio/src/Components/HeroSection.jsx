import React from 'react';
import bgimage from '../assets/banner-background-one.jpg'
import bannerImage from '../assets/Shivani.jpg'
import TypingText from '../TypingText';

const HeroSection = () => {
  return (
    <section className="hero-section d-flex align-items-center text-white" style={{ backgroundImage: `url(${bgimage})` }}>
      <div className="container">
        <div className="row align-items-center">
          
          <div className="col-md-6">
            <h1 className="display-5 fw-bold mb-3">
              <span className='fs-4'>HELLO</span><br />I’m Shivani Rana a<br /><span className="text-pink"><TypingText /></span>
            </h1>
            <p className="mb-4">
              A personal portfolio is a collection of your work, achievements, and skills that highlights your abilities and professional growth. It serves as...
            </p>
            <a href="#" className="btn btn-danger text-white px-4 py-2 rounded-pill">
              View Portfolio <i className="fas fa-arrow-right ms-2"></i>
            </a>
          </div>

          <div className="col-md-6 text-center">
            <img src={bannerImage} alt="Banner" className="img-fluid hero-image rounded-circle" />
          </div>

        </div>
      </div>
    </section>
  );
};

export default HeroSection;
