import React from 'react'
import { Link } from 'react-router-dom';


function SubBanner({ title, bannerImage, currentPage }) {
  return (
    <section
      className="about-sub-banner d-flex align-items-center"
      style={{
        backgroundImage: `url(${bannerImage})`,
      }}
    >
      <div className="container text-center text-white" style={{ position: 'relative', zIndex: 2 }}>
        <h1 className="display-5 fw-bold mt-5">{title}</h1>
        <p className="breadcrumb-text d-flex justify-content-center align-items-center">
                      <Link to="/" className="text-white text-decoration-none me-1">Home</Link>
 <i class="fa-solid fa-angle-right mx-2 fs-6"></i>
  {currentPage}</p>
      </div>
    </section>
  )
}

export default SubBanner