import React from 'react';
import { Link } from 'react-router-dom'
import '../index.css';
import Header from '../MainPart/Header';
import HeroSection from './HeroSection';
import Education from './Education';
import Footer from '../MainPart/Footer';
import Portfolio from './Portfolio';
import Contactform from './Contactform';

function Home() {
  return (
    <>
      <Header />
      <HeroSection/>
      <Education/>
      <Portfolio/>
      <Contactform/>
      <Footer/>
    </>
  );
}

export default Home;
