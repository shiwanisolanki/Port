import React from 'react';

function NotFound() {
  return (
    <div className="text-center mt-5">
      <h2>404 - Page Not Found</h2>
      <p>Oops! The page or file you're looking for doesn't exist.</p>
    </div>
  );
}

export default NotFound;
