import React from 'react'
import { ProjectImages } from '../assets/Data/ProjectsData'
import { Link } from 'react-router-dom';

function Portfolio() {
  return (
    <section className="Portfolio my-5">
        <div className="container">
             {/* Section Title */}
                <div className="text-center mb-5">
                    <h2 className="section-title">Portfolio</h2>
                    <p className="section-subtitle"> Creative projects <br /> built with code.</p>
                </div>
                <div className="row">
                    {ProjectImages.map((v,i) => (
                        <div className="col-md-6 mb-5" key={i}>
                            <div className="card w-100 projectimages">
                                <img src={v.image} alt={v.title} className='img-fluid w-100 border-pink shadow' style={{ objectFit: 'cover', height: '300px' }}/>
                            </div>
                            <div className="projectcontent pt-3">
                                <div className="content-left">
                                    <h3>
                                        <Link to={`/project/${v.id}`} target='blank' className="link text-white text-decoration-none">{v.title}</Link>
                                    </h3>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
        </div>
    </section>
  )
}

export default Portfolio