import React from 'react'
import Header from '../MainPart/Header'
import SubBanner from './SubBanner'
import Footer from '../MainPart/Footer'
import contactBanner from '../assets/banner-background-one.jpg';


function Contact() {
  return (
    
    <>
    <Header/>
    <SubBanner 
        title="Contact Me" 
        bannerImage={contactBanner} 
        currentPage="Contact" 
      />
    <Footer/>
    </>
  )
}

export default Contact