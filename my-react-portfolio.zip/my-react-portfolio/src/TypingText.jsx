import React from 'react'
import { TypeAnimation } from 'react-type-animation';

const TypingText = () => {
  return (
    <span className="">
      {' '}
      <TypeAnimation
        sequence={[
          'Web Designer.',
          2000,
          'Web Developer.',
          2000,
          'React Developer.',
          2000,
          'Frontend Developer.',
          2000,
         
        ]}
        wrapper="span"
        speed={50}
        repeat={Infinity}
      />
    </span>
  )
}

export default TypingText;